class Connect5 {
   constructor() {
     this.cols = 9;
     this.rows = 6;
     this.grid = [['-','-','-','-','-','-','-','-','-'],
              ['-','-','-','-','-','-','-','-','-'],
              ['-','-','-','-','-','-','-','-','-'],
              ['-','-','-','-','-','-','-','-','-'],
              ['-','-','-','-','-','-','-','-','-'],
              ['-','-','-','-','-','-','-','-','-']];
      this.players = []
      this.pairedPlayers= []
   }

   getPrintableGrid() {
     var colNums = Array.from(Array(this.cols).keys());
     colNums = colNums.map(x=> x.toString()).join('   ');
     var printable = [];
     printable.push(colNums);
     printable.push('================================');
     for(var row of this.grid){
       var cleanedRow = [];
       for(var column of row){
         cleanedRow.push(column);
       }
       printable.push(cleanedRow.join('   '));
     }
     return(printable);
   }

   createNewPlayer(name) {
     var value = this.players.length
     var player = new Player(name, value)
     this.players.push(player)
   }

   isReadyToPlay(){
     if(this.players.length == 2){
       return true;
     }else{
       return false;
     }
   }

}

class Player {
  constructor(name, value){
    this.name = name;
    this.value = value;
  }
}

module.exports = {
  game: Connect5,
  player: Player
};
